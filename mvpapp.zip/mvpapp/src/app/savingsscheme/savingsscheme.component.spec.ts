import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SavingsschemeComponent } from './savingsscheme.component';

describe('SavingsschemeComponent', () => {
  let component: SavingsschemeComponent;
  let fixture: ComponentFixture<SavingsschemeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SavingsschemeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SavingsschemeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
